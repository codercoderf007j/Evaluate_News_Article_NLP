function checkForName(inputText) {
    console.log("::: Running checkForName :::", inputText);
    let names = [
        "User one",
        "User two",
        "User three",
        "User four",
        "User five"
    ]

    if(names.includes(inputText)) {
        alert("Welcome, Dear User!")
    }
}

export { checkForName }
